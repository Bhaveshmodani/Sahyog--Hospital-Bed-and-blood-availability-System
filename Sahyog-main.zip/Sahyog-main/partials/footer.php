<footer class="text-center text-lg-start text-white" id="f" style="background-color: #1c2331">

    <section
             class="d-flex justify-content-between p-4"
             style="background-color: #6351ce"
             >
    </section>
  
    <section class="">
      <div class="container text-center text-md-start mt-5">
        <div class="row mt-3">
          <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
            <h6 class="text-uppercase fw-bold">SAHYOG</h6>
            <hr
                class="mb-4 mt-0 d-inline-block mx-auto"
                style="width: 60px; background-color: #7c4dff; height: 2px"
                />
            <p>
              ONE STOP SOLUTION FOR FINDING BED AVAILABILITY AT YOUR CITY
            </p>
          </div>
          <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 class="text-uppercase fw-bold">LINKS</h6>
            <hr
                class="mb-4 mt-0 d-inline-block mx-auto"
                style="width: 60px; background-color: #7c4dff; height: 2px"
                />
            <p>
              <a href="./faq.html" class="text-white">FAQ</a>
            </p>
            <p>
              <a href="./about.html" class="text-white">ABOUT</a>
            </p>
            <p>
              <a href="./contact_us.php" class="text-white">CONTACT US</a>
            </p>
          </div>

          <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-md-0 mb-4">

            <h6 class="text-uppercase fw-bold">CONTACT</h6>
            <hr
                class="mb-4 mt-0 d-inline-block mx-auto"
                style="width: 60px; background-color: #7c4dff; height: 2px"
                />
            <p><i class="fas fa-home mr-3"></i>Nagpur,Maharashtra</p>
            <p><i class="fas fa-envelope mr-3">davecr@rknec.edu</p>
            <p><i class="fas fa-envelope mr-3">modanibs@rknec.edu</p>
          </div>
        </div>
      </div>
    </section>
    <div
         class="text-center p-3"
         style="background-color: rgba(0, 0, 0, 0.2)"
         >
    </div>


